HONYCOMB CELL DENSITY — VERSI WINDOWS EXE

Isi project:
- index.html        = aplikasi Honycomb Cell Density dari file yang Anda kirim
- opencv.js         = OpenCV lokal
- qrcode.min.js     = QR Code lokal
- cataler_logo.jpg  = logo CATALER
- main.js           = pembuka aplikasi Electron
- package.json      = konfigurasi build EXE

CARA MEMBUAT EXE DI WINDOWS
1. Install Node.js LTS di Windows.
2. Ekstrak folder ini.
3. Buka Command Prompt / PowerShell di folder ini.
4. Jalankan:
   npm install
5. Untuk mencoba aplikasi:
   npm start
6. Jika sudah sesuai, buat installer EXE:
   npm run dist
7. File installer akan muncul di folder:
   dist

CATATAN:
- Pertama kali menjalankan npm install, komputer perlu internet untuk mengunduh Electron dan electron-builder.
- Setelah EXE selesai dibuat, aplikasi dapat menggunakan OpenCV.js dan QRCode.js yang sudah dibundel secara lokal.
- Algoritma aplikasi pada index.html tidak diubah; hanya sumber OpenCV.js dan QRCode.js diarahkan ke file lokal agar dapat dipaketkan oleh Electron.
